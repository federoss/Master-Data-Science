library(shiny)

shinyUI(
  
  fluidPage(
    titlePanel("Old Faithful Geysser"),
    sidebarLayout( 
      sidebarPanel(
        sliderInput( "bins", "Number of bins",0,25,13) # entrecomillado porque no es ninguna palabra ni funcion determinada de R
      ),
        mainPanel(
          plotOutput("plot")
        )
     
    )
  )
  
)
