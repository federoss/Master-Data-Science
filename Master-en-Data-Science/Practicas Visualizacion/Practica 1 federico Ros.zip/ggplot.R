library(ggplot2)

mpg

ggplot(mpg,aes(class))

ggplot(mpg,aes(class))+geom_bar()

ggplot(mpg,aes(class))+geom_point()

ggplot(mpg,aes(x=class,y=displ))+geom_point()

ggplot(mpg,aes(x=class,y=displ))+ # contrl  + enter para ejecutar con teclado.
  geom_point()

ggplot(mpg,aes(x=cty,y=displ,colour=class,size=hwy))+geom_point() # cuatro caracteristicas importantes variables, 1)a veces como en el calendario gregoriano el cero no tiene significado,
# 2)las clases, categoricas, porque no las puedes ordenar 
ggplot(mpg,aes(x=cty,y=displ,colour=hwy,size=hwy))+geom_point()
# Graficacon varias capas: añadiendo con el operador "+" todas las geom_...() que necesitemos.
ggplot(mpg,aes(x=cty,y=displ))+geom_point(colour=class,size=hwy)

ggplot(mpg,aes(x=cty,y=displ))+geom_point(aes(colour=class,size=hwy))

ggplot(mpg,aes(x=cty))+
  geom_bar(fill="GREY")+ # funcion geom_bar no hace caso(ignora) a size porque no la utiliza
  geom_jitter(aes(y=displ,colour=class,size=hwy),alpha=0.6) #porque la Y solo afecta a los puntos no a las barras. #alpha o nivel de opacidad tiene que ir fuera de aes ya que no es una aesthetics y R lo toma como variable.
ggplot(mpg, aes(x=cty,y=hwy)) + 
  geom_point( ) +
  facet_grid(year~class) # funcion divide la muestra en los diferentes subgrupos.

View(mpg)

ggplot(mpg,aes(x=cyl,y=displ)) + 
  geom_point() +
  facet_grid(.~manufacturer)

ggplot(mpg,aes(x=cyl,y=displ)) + 
  geom_point() +
  facet_wrap(~manufacturer,ncol=3) + # facet wrap sin punto (excepcion)
  theme_bw()

ggplot(mpg,aes(x=class)) + geom_bar()

ggplot(mpg, aes(x=cyl, y=displ)) + 
  geom_point() + 
  stat_smooth(method="lm")

  