

#A través de la siguiente función estamos haciendo que el histograma(output) 
#dependa de los valores que tenga en cada momento la barra de bins(imput), quedando por lo tanto vinculado.

library(shiny)
library(ggplot2)

function(input, output) {
  output$grafica <- renderPlot({
    graficaBase <- ggplot(mpg, aes_string(x=input$variablex, y=input$variabley )) +
      geom_point()
    if (input$facet){
      graficaBase+facet_wrap(~manufacturer, ncol=4)
      if (input$colorear_tipo)
        graficaBase+facet_wrap(~manufacturer, ncol=4)+geom_point(aes(colour = class))
      else
        graficaBase+facet_wrap(~manufacturer, ncol=4)
    }
    else{
      graficaBase
      if (input$colorear_tipo)
        graficaBase+geom_point(aes(colour = class))
      else
        graficaBase
    }
    
  })
  
  output$texto <- renderText({
    nth <- paste0(c("Diagrama de dispersión--> Eje X: "), input$variablex, c(" . Eje Y: "), input$variabley)
  })
}
  