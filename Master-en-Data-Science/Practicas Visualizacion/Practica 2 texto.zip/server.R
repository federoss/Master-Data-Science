library(shiny)
library(ggplot2)

function(input, output) {
  output$grafica <- renderPlot({
      graficaBase <- ggplot(mpg, aes_string(x=input$variablex, y=input$variabley )) +
        geom_point()
      if (input$facet){
        graficaBase+facet_wrap(~manufacturer, ncol=4)
        if (input$colorear_tipo)
          graficaBase+facet_wrap(~manufacturer, ncol=4)+geom_point(aes(colour = class))
        else
          graficaBase+facet_wrap(~manufacturer, ncol=4)
      }
      else{
        graficaBase
        if (input$colorear_tipo)
          graficaBase+geom_point(aes(colour = class))
        else
          graficaBase
      }

    })

  output$texto <- renderText({
    #VOY A NECESITAR PASTE0
    #"Hola caracola"
    nth <- paste0(c("Diagrama de dispersión ==> X: "), input$variablex, c(" //  Y: "), input$variabley)
  })
}